package com.example.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.ocr.models.OCRResult
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions

class OCRHelper(private val context: Context) {

    private val recognizer = TextRecognition.getClient(
        ChineseTextRecognizerOptions.Builder().build()
    )

    fun recognize(uri: Uri, callback: (OCRResult) -> Unit) {
        try {
            val bitmap = loadBitmap(uri)
            if (bitmap == null) {
                callback(OCRResult(uri, "", false))
                return
            }

            val image = InputImage.fromBitmap(bitmap, 0)

            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val text = visionText.text
                    callback(OCRResult(uri, text, true))
                }
                .addOnFailureListener { e ->
                    e.printStackTrace()
                    callback(OCRResult(uri, "", false))
                }
        } catch (e: Exception) {
            e.printStackTrace()
            callback(OCRResult(uri, "", false))
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val options = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                BitmapFactory.decodeStream(inputStream, null, options)

                val scale = maxOf(
                    options.outWidth / 1080,
                    options.outHeight / 1080
                )

                val finalOptions = BitmapFactory.Options().apply {
                    inSampleSize = if (scale > 1) scale else 1
                }

                context.contentResolver.openInputStream(uri)?.use { newStream ->
                    BitmapFactory.decodeStream(newStream, null, finalOptions)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun close() {
        recognizer.close()
    }
}