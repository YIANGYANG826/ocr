package com.example.ocr

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ImageAdapter(
    private val onItemClick: (position: Int, uri: Uri) -> Unit
) : RecyclerView.Adapter<ImageAdapter.ViewHolder>() {

    private var images = listOf<Uri>()

    fun submitList(list: List<Uri>) {
        images = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_image, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val uri = images[position]
        holder.bind(uri, position + 1)
        holder.itemView.setOnClickListener {
            onItemClick(position, uri)
        }
    }

    override fun getItemCount() = images.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imageView: ImageView = itemView.findViewById(R.id.ivThumb)
        private val tvIndex: TextView = itemView.findViewById(R.id.tvIndex)

        fun bind(uri: Uri, index: Int) {
            tvIndex.text = index.toString()
            Glide.with(itemView.context)
                .load(uri)
                .centerCrop()
                .into(imageView)
        }
    }
}