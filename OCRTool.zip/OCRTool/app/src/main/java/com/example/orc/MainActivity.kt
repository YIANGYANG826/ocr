package com.example.ocr

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ocr.databinding.ActivityMainBinding
import com.example.ocr.models.OCRResult
import com.github.dhaval2404.imagepicker.ImagePicker
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var imageAdapter: ImageAdapter
    private val selectedImages = mutableListOf<Uri>()  // 保持顺序
    private val ocrResults = mutableListOf<OCRResult>()
    private val filterManager = FilterManager(this)

    private val imagePickerLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val uri = result.data?.data
            if (uri != null) {
                selectedImages.add(uri)
                imageAdapter.submitList(selectedImages.toList())
                binding.tvImageCount.text = "已选 ${selectedImages.size} 张"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupViews()
        setupRecyclerView()
    }

    private fun setupViews() {
        binding.btnSelectImages.setOnClickListener {
            ImagePicker.with(this)
                .galleryOnly()
                .compress(1024)
                .maxResultSize(1080, 1080)
                .createIntent { intent ->
                    imagePickerLauncher.launch(intent)
                }
        }

        binding.btnClear.setOnClickListener {
            selectedImages.clear()
            ocrResults.clear()
            imageAdapter.submitList(emptyList())
            binding.tvImageCount.text = "已选 0 张"
            binding.tvResult.text = ""
            binding.tvFilterInfo.text = "当前图片屏蔽词信息"
        }

        binding.btnGlobalFilter.setOnClickListener {
            showFilterDialog("全局屏蔽词", filterManager.getGlobalFilters()) { filters ->
                filterManager.setGlobalFilters(filters)
            }
        }

        binding.btnRecognize.setOnClickListener {
            if (selectedImages.isEmpty()) {
                Toast.makeText(this, "请先选择图片", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startRecognition()
        }

        binding.btnCopyAll.setOnClickListener {
            copyAllResults()
        }

        binding.btnExport.setOnClickListener {
            exportToTxt()
        }
    }

    private fun setupRecyclerView() {
        imageAdapter = ImageAdapter { position, uri ->
            if (position < ocrResults.size) {
                val result = ocrResults[position]
                displayResult(result, position)

                val filters = filterManager.getImageFilters(uri.toString())
                val filterInfo = buildString {
                    append("全局屏蔽词: ${filterManager.getGlobalFilters().size}个\n")
                    append("本图专用: ${filters.joinToString()}")
                }
                binding.tvFilterInfo.text = filterInfo
            }

            binding.btnImageFilter.setOnClickListener {
                showFilterDialog(
                    "图片专用屏蔽词",
                    filterManager.getImageFilters(uri.toString())
                ) { filters ->
                    filterManager.setImageFilters(uri.toString(), filters)
                }
            }
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = imageAdapter
    }

    private fun showFilterDialog(
        title: String,
        existingFilters: List<String>,
        onSave: (List<String>) -> Unit
    ) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)

        val input = EditText(this)
        input.setHint("每行一个屏蔽词")
        input.setText(existingFilters.joinToString("\n"))
        input.setPadding(50, 30, 50, 30)

        builder.setView(input)
        builder.setPositiveButton("保存") { _, _ ->
            val text = input.text.toString()
            val filters = text.split("\n")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
            onSave(filters)
            Toast.makeText(this, "已保存 ${filters.size} 个屏蔽词", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton("取消", null)
        builder.show()
    }

    private fun startRecognition() {
        binding.progressBar.visibility = View.VISIBLE
        binding.tvStatus.text = "识别中... 0/${selectedImages.size}"

        ocrResults.clear()

        val ocrHelper = OCRHelper(this)

        fun recognizeNext(index: Int) {
            if (index >= selectedImages.size) {
                binding.progressBar.visibility = View.GONE
                binding.tvStatus.text = "识别完成"
                imageAdapter.notifyDataSetChanged()
                if (ocrResults.isNotEmpty()) {
                    displayResult(ocrResults[0], 0)
                }
                return
            }

            val uri = selectedImages[index]
            binding.tvStatus.text = "识别中... ${index + 1}/${selectedImages.size}"

            ocrHelper.recognize(uri) { result ->
                var text = result.text
                filterManager.getGlobalFilters().forEach { word ->
                    text = text.replace(word, "")
                }
                filterManager.getImageFilters(uri.toString()).forEach { word ->
                    text = text.replace(word, "")
                }

                ocrResults.add(OCRResult(uri, text, result.success))
                recognizeNext(index + 1)
            }
        }

        recognizeNext(0)
    }

    private fun displayResult(result: OCRResult, position: Int) {
        binding.tvResult.text = if (result.success) {
            result.text
        } else {
            "[识别失败]"
        }
    }

    private fun copyAllResults() {
        val sb = StringBuilder()
        ocrResults.forEachIndexed { index, result ->
            sb.append("=== 图片 ${index + 1} ===\n")
            sb.append(result.text)
            sb.append("\n\n")
        }

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("OCR Results", sb.toString())
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "已复制到剪贴板", Toast.LENGTH_SHORT).show()
    }

    private fun exportToTxt() {
        if (ocrResults.isEmpty()) {
            Toast.makeText(this, "没有识别结果", Toast.LENGTH_SHORT).show()
            return
        }

        val sb = StringBuilder()
        ocrResults.forEachIndexed { index, result ->
            sb.append("=== 图片 ${index + 1} ===\n")
            sb.append(result.text)
            sb.append("\n\n")
        }

        val fileName = "OCR_Results_${System.currentTimeMillis()}.txt"
        val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val file = File(downloadDir, fileName)

        try {
            file.writeText(sb.toString(), Charsets.UTF_8)
            Toast.makeText(this, "已保存到: $fileName", Toast.LENGTH_LONG).show()
            sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)))
        } catch (e: Exception) {
            Toast.makeText(this, "保存失败: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}